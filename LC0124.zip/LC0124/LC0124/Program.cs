﻿// MIS 3013 005
// Jan 24, 2024
// Andrea Hernandez
// 113552217

// define variable
// int double bool char
// int : 1 2 3 -1 0
// double : 12.6
// bool : true false
// char : one single character
// datatype variable_name;
// 1. letter number _
// 2. start with letter or _ (could not start with a number)
// int double bool char: simple datatype, not expendive resources in the computer
int age1;// datatype is int, age1 is the variable
int age2;//

double weight1;
double weight2;

bool b1;
bool b2;

char c1;
char c2;
// to put values into the space, we use assignment operation
// = assignment operator, very very important concept in programming
// variable_name = expression;
age1 = 20;
age2 = 2 * 15;

weight1 = age1 * 10;

Console.WriteLine(weight1);
Console.WriteLine(age2);

